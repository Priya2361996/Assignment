-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2021 at 09:53 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_cricket`
--

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `country_id` varchar(5) NOT NULL,
  `country_name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`country_id`, `country_name`) VALUES
('C01', 'India'),
('C02', 'England'),
('C03', 'Pakistan'),
('C04', 'New zealand');

-- --------------------------------------------------------

--
-- Table structure for table `matches`
--

CREATE TABLE `matches` (
  `match_id` varchar(10) NOT NULL,
  `match_date` varchar(15) NOT NULL,
  `venue_id` varchar(10) NOT NULL,
  `team1` varchar(20) NOT NULL,
  `team2` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `matches`
--

INSERT INTO `matches` (`match_id`, `match_date`, `venue_id`, `team1`, `team2`) VALUES
('m01', '05-JUN-2021 ', 'v1', 'India', 'England'),
('m02', '07-JUN-2021', 'v1', 'India', 'New zealand');

-- --------------------------------------------------------

--
-- Table structure for table `match_summary`
--

CREATE TABLE `match_summary` (
  `ms_id` varchar(10) NOT NULL,
  `man_of_the_match` varchar(15) NOT NULL,
  `bowler_of_the_match` varchar(15) NOT NULL,
  `Best Fielder` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `match_summary`
--

INSERT INTO `match_summary` (`ms_id`, `man_of_the_match`, `bowler_of_the_match`, `Best Fielder`) VALUES
('MS001', 'p1', 'p2', 'p4'),
('MS002', 'p2', 'p3', 'p4');

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `player_id` varchar(10) NOT NULL,
  `player_name` varchar(50) NOT NULL,
  `player_type` varchar(20) NOT NULL,
  `team_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`player_id`, `player_name`, `player_type`, `team_id`) VALUES
('p1', 'Sachin Tendulkar', 'Batsman', 't1'),
('p2', 'Ben Stokes', 'All Rouder', 't2'),
('p3', 'Youraj', 'Bowler', 't1'),
('p4', 'Dhoni', 'Fielder', 't1'),
('p5', 'Ross Taylor', 'Batsman', 't3');

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `result_id` varchar(10) NOT NULL,
  `result_status` varchar(15) NOT NULL,
  `result_date` varchar(10) NOT NULL,
  `team_id` varchar(10) NOT NULL,
  `match_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`result_id`, `result_status`, `result_date`, `team_id`, `match_id`) VALUES
('R01', 'Winner', '05/07/2021', 't1', 'm02'),
('R02', 'Winner', '07/06/2021', 't2', 'm01');

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `team_id` varchar(10) NOT NULL,
  `team_name` varchar(50) NOT NULL,
  `country_id` varchar(10) NOT NULL,
  `player_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`team_id`, `team_name`, `country_id`, `player_id`) VALUES
('t1', 'Indian Cricket League', 'C01', 'p1'),
('t2', 'England Cricket League', 'C02', 'p2'),
('t3', 'New zealand', 'C03', 'p5');

-- --------------------------------------------------------

--
-- Table structure for table `venue`
--

CREATE TABLE `venue` (
  `venue_id` varchar(10) NOT NULL,
  `venue_city` varchar(15) NOT NULL,
  `venue_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `venue`
--

INSERT INTO `venue` (`venue_id`, `venue_city`, `venue_name`) VALUES
('v1', 'Mumbai', 'Wankhede Stadium'),
('v2', 'Pune', 'Balewadi Stadium');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`country_id`);

--
-- Indexes for table `matches`
--
ALTER TABLE `matches`
  ADD PRIMARY KEY (`match_id`);

--
-- Indexes for table `match_summary`
--
ALTER TABLE `match_summary`
  ADD PRIMARY KEY (`ms_id`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`player_id`);

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`result_id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`team_id`);

--
-- Indexes for table `venue`
--
ALTER TABLE `venue`
  ADD PRIMARY KEY (`venue_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
