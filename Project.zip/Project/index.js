const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const mysql = require("mysql");

// parse application/json
app.use(bodyParser.json());

//Create Database Connection
const conn = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "project_cricket",
});

conn.connect((err) => {
    if (err) throw err;
});

// view winner team
app.get("/api/view/winnerteam", verifyToken, (req, res) => {
    let sql = "SELECT m.team1,m.team2,v.venue_city,v.venue_name,r.result_status,t.team_name as Winner_Team FROM matches m INNER JOIN venue v ON m.venue_id = v.venue_id INNER JOIN results r ON m.match_id = r.match_id INNER JOIN team t ON r.team_id = t.team_id";
    let query = conn.query(sql, (err, result) => {
        if (err) throw err;
        res.send(JSON.stringify({ status: 200, error: null, response: result }));
    });
});



app.get("/api/view", verifyToken, (req, res) => {
    let sql = "select p.player_id,p.player_name,t.team_name From players p Inner JOIN team t on p.player_id = t.player_id";
    let query = conn.query(sql, (err, result) => {
        if (err) throw err;
        res.send(JSON.stringify({ status: 200, error: null, response: result }));
    });
});


function verifyToken(req, res, next) {
    const bearerHeader = req.headers['authorization'];
    if (typeof bearerHeader !== 'undefined') {
        const bearer = bearerHeader.split(' ');
        const bearerToken = bearer[1];
        const bpassword = "priya123";
        if (bearerToken === bpassword) {
            next();
        } else {
            res.sendStatus(403);
        }
    } else {

        res.sendStatus(403);
    }

}

app.listen(8000, () => {
    console.log("server started on port 8000...");
});